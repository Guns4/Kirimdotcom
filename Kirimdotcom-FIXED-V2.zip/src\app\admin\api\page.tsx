export default function API() {
  return <div className="p-6"><h1>API Dashboard</h1></div>;
}

import { Metadata } from 'next';
import { JsonLd } from '@/components/seo/JsonLd';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import { Package, Truck, ArrowLeft, MapPin } from 'lucide-react';

interface PageProps {
  params: Promise<{
    slug: string[];
  }>;
}

export async function generateMetadata({
  params,
}: PageProps): Promise<Metadata> {
  const { slug } = await params;

  // valid slug: [courier, resi] e.g. ['jne', 'CGK123456']
  if (slug.length < 2) return { title: 'Cek Resi' };

  const courier = slug[0].toUpperCase();
  const resi = slug[1];

  return {
    title: `Lacak Paket ${courier} ${resi} - Status Terkini`,
    description: `Cek status pengiriman paket ${courier} dengan nomor resi ${resi}. Lacak posisi paket secara real-time.`,
    openGraph: {
      title: `Lacak Paket ${courier} - ${resi}`,
      description: `Status pengiriman terkini untuk nomor resi ${resi} (${courier})`,
    },
  };
}

export default async function TrackingPage({ params }: PageProps) {
  const { slug } = await params;

  if (slug.length < 2) {
    notFound();
  }

  const courierCode = slug[0].toLowerCase();
  const resiNumber = slug[1];

  // ParcelDelivery Schema
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'ParcelDelivery',
    deliveryStatus: {
      '@type': 'DeliveryEvent',
      availableFrom: new Date().toISOString(),
    },
    trackingNumber: resiNumber,
    provider: {
      '@type': 'Organization',
      name: courierCode.toUpperCase(),
    },
    expectedArrivalFrom: new Date().toISOString(),
    hasDeliveryMethod: 'http://schema.org/ParcelService',
  };

  return (
    <main className="min-h-screen bg-slate-950 py-20 px-4">
      <JsonLd data={jsonLd} />
      <div className="max-w-2xl mx-auto">
        <Link
          href="/"
          className="inline-flex items-center gap-2 text-gray-400 hover:text-white mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Kembali ke Beranda
        </Link>

        <div className="glass-card p-8 text-center">
          <div className="w-16 h-16 bg-indigo-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <Package className="w-8 h-8 text-indigo-400" />
          </div>

          <h1 className="text-2xl font-bold text-white mb-2">
            Tracking {courierCode.toUpperCase()}
          </h1>
          <p className="text-xl font-mono text-indigo-300 mb-6">{resiNumber}</p>

          <div className="bg-white/5 rounded-xl p-6 text-left">
            <h2 className="text-sm font-semibold text-gray-400 mb-4 uppercase tracking-wider">
              Status Pengiriman
            </h2>
            {/* 
                           In a real app, we would fetch tracking data server-side here.
                           For now, we render the layout and schema as requested.
                        */}
            {/* Mock Tracking History for Demo/Simulation */}
            <div className="space-y-8 relative before:absolute before:inset-0 before:ml-5 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-transparent before:via-gray-700 before:to-transparent">
              {[
                {
                  status: 'DELIVERED',
                  desc: 'Paket telah diterima oleh [Yanto - Ybs]',
                  date: new Date().toLocaleDateString('id-ID', {
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric',
                  }),
                  time: '14:30',
                  icon: Package,
                  color: 'text-green-400',
                  bg: 'bg-green-500',
                },
                {
                  status: 'ON DELIVERY',
                  desc: 'Paket dibawa kurir [Sigesit] menuju alamat tujuan',
                  date: new Date().toLocaleDateString('id-ID', {
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric',
                  }),
                  time: '08:15',
                  icon: Truck,
                  color: 'text-blue-400',
                  bg: 'bg-blue-500',
                },
                {
                  status: 'ARRIVED AT HUB',
                  desc: 'Paket telah sampai di Gudang DC Cakung',
                  date: new Date(Date.now() - 86400000).toLocaleDateString(
                    'id-ID',
                    { day: 'numeric', month: 'long', year: 'numeric' }
                  ),
                  time: '23:45',
                  icon: MapPin,
                  color: 'text-indigo-400',
                  bg: 'bg-indigo-500',
                },
                {
                  status: 'MANIFESTED',
                  desc: 'Paket telah diterima oleh agen',
                  date: new Date(Date.now() - 172800000).toLocaleDateString(
                    'id-ID',
                    { day: 'numeric', month: 'long', year: 'numeric' }
                  ),
                  time: '19:20',
                  icon: Package,
                  color: 'text-slate-400',
                  bg: 'bg-slate-500',
                },
              ].map((item, idx) => (
                <div
                  key={idx}
                  className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active"
                >
                  <div className="flex items-center justify-center w-10 h-10 rounded-full border border-white/10 bg-slate-900 shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2">
                    <item.icon className={`w-5 h-5 ${item.color}`} />
                  </div>
                  <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] bg-white/5 p-4 rounded-xl border border-white/10 hover:border-indigo-500/50 transition-colors">
                    <div className="flex items-center justify-between mb-1">
                      <span className={`font-bold text-sm ${item.color}`}>
                        {item.status}
                      </span>
                      <time className="font-mono text-xs text-slate-500">
                        {item.date} {item.time}
                      </time>
                    </div>
                    <p className="text-slate-300 text-sm leading-relaxed">
                      {item.desc}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-8">
            <Link
              href={`/?tracking=${resiNumber}&courier=${courierCode}`}
              className="inline-flex items-center gap-2 px-6 py-3 bg-white/10 hover:bg-white/20 text-white rounded-xl transition-all font-medium"
            >
              <Truck className="w-5 h-5" />
              Lihat Detail Lengkap
            </Link>
          </div>
        </div>
      </div>
    </main>
  );
}

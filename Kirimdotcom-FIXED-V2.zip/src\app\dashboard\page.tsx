import React from 'react';

export default function DashboardPage() {
  return (
    <div className="p-10 text-center">
      <h1 className="text-2xl font-bold">Member Area</h1>
      <p>Selamat datang di dashboard member. Fitur akan segera diaktifkan.</p>
    </div>
  );
}
